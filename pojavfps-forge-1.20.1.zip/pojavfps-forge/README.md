# ⚡ PojavFPS Client — Forge 1.20.1

Mod de FPS boost para Minecraft 1.20.1 com Forge, otimizado para PojavLauncher.

## 🎮 Como usar
- Pressione **R-Shift (Shift Direito)** para abrir o menu de FPS
- Clique nas abas: RENDER / ENTIDADE / MUNDO / POJAV
- Ative/desative as opções com clique
- Clique em **✔ APLICAR** para salvar
- Clique em **MAX FPS** para ativar tudo de uma vez

## 🛠️ Como compilar

### Requisitos
- Java 17 (JDK 17)
- Git

### Passos

```bash
# 1. Clone ou extraia o projeto
cd pojavfps-forge

# 2. No Windows:
gradlew.bat build

# No Linux/Mac:
./gradlew build

# 3. O .jar estará em:
build/libs/pojavfps-1.0.0.jar
```

## 📦 Instalação no PojavLauncher

1. Instale o **Forge 1.20.1-47.2.0** no PojavLauncher
2. Copie o `pojavfps-1.0.0.jar` para:
```
/sdcard/Android/data/net.kdt.pojavlaunch/files/.minecraft/mods/
```
3. Inicie o Minecraft com o perfil Forge 1.20.1
4. Pressione **R-Shift** para abrir o menu!

## ⚡ O que cada opção faz

### Aba RENDER
| Opção | FPS Ganho |
|-------|-----------|
| Gráficos Rápidos | +15 FPS |
| Desligar Nuvens | +8 FPS |
| Desligar Névoa | +6 FPS |
| Partículas Reduzidas | +10 FPS |
| Desligar Chuva/Neve | +12 FPS |

### Aba ENTIDADE
| Opção | FPS Ganho |
|-------|-----------|
| Entity Culling | +20 FPS |
| Desligar Sombras | +10 FPS |
| Limitar Tick de Entidades | +15 FPS |

### Aba MUNDO
| Opção | FPS Ganho |
|-------|-----------|
| Folhas Rápidas | +8 FPS |
| Reduzir Atualizações de Chunk | +12 FPS |

## 📁 Estrutura do Projeto

```
pojavfps-forge/
├── build.gradle
├── settings.gradle
└── src/main/
    ├── java/com/pojavfps/
    │   ├── PojavFPS.java          ← Classe principal do mod
    │   ├── config/
    │   │   └── FPSConfig.java     ← Todas as configurações
    │   ├── gui/
    │   │   ├── FPSMenuScreen.java ← Tela do menu
    │   │   └── ToggleOption.java  ← Widget de toggle
    │   └── keybind/
    │       └── KeyBindings.java   ← Tecla R-Shift
    └── resources/
        ├── pack.mcmeta
        └── META-INF/
            ├── mods.toml
            └── accesstransformer.cfg
```

## ⚠️ JVM Args recomendados no PojavLauncher

Em Configurações → Java → JVM Arguments:
```
-Xmx1G -Xms512M -XX:+UseG1GC -XX:MaxGCPauseMillis=50 -XX:+UnlockExperimentalVMOptions
```
