package com.pojavfps.config;

public class FPSConfig {

    // Render
    public static boolean entityCulling = true;
    public static boolean reducedParticles = true;
    public static boolean disableClouds = true;
    public static boolean fastGraphics = true;
    public static boolean disableWeather = false;
    public static boolean limitFramerate = false;
    public static int framerateLimit = 60;
    public static int renderDistance = 6;
    public static int simulationDistance = 4;

    // Entity
    public static boolean limitEntityTick = true;
    public static int entityTickLimit = 50;
    public static boolean disableEntityShadows = true;
    public static boolean skipOffscreenEntities = true;

    // World
    public static boolean reducedFOV = false;
    public static boolean disableFog = true;
    public static boolean fastLeaves = true;
    public static boolean minimalChunkUpdates = true;

    // Mobile (PojavLauncher)
    public static boolean pojavMode = true;
    public static boolean reducedHUD = false;
    public static boolean touchOptimize = true;

    public static void init() {
        // Apply all settings on load
        applyAll();
    }

    public static void applyAll() {
        applyRenderSettings();
        applyEntitySettings();
        applyWorldSettings();
    }

    public static void applyRenderSettings() {
        try {
            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
            if (mc == null || mc.options == null) return;

            if (fastGraphics) {
                mc.options.graphicsMode().set(net.minecraft.client.GraphicsStatus.FAST);
            }
            if (disableClouds) {
                mc.options.cloudStatus().set(net.minecraft.client.CloudStatus.OFF);
            }

            mc.options.renderDistance().set(renderDistance);
            mc.options.simulationDistance().set(simulationDistance);

            if (limitFramerate) {
                mc.options.framerateLimit().set(framerateLimit);
            } else {
                mc.options.framerateLimit().set(260); // unlimited-ish
            }

            mc.options.save();
        } catch (Exception ignored) {}
    }

    public static void applyEntitySettings() {
        // Entity culling handled via tick event in EntityOptimizer
    }

    public static void applyWorldSettings() {
        try {
            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
            if (mc == null || mc.options == null) return;

            if (fastLeaves) {
                // Fast leaves = FAST graphics already handles this
            }
            mc.options.save();
        } catch (Exception ignored) {}
    }
}
