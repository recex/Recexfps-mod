package com.pojavfps.keybind;

import com.mojang.blaze3d.platform.InputConstants;
import com.pojavfps.gui.FPSMenuScreen;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

public class KeyBindings {

    public static KeyMapping OPEN_MENU;

    public static void register() {
        OPEN_MENU = new KeyMapping(
            "key.pojavfps.open_menu",
            KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "key.categories.pojavfps"
        );
    }

    public static void onRegisterKeyMappings(RegisterKeyMappingsEvent event) {
        event.register(OPEN_MENU);
    }

    public static void handleKeyPress() {
        if (OPEN_MENU == null) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen == null && OPEN_MENU.consumeClick()) {
            mc.setScreen(new FPSMenuScreen());
        }
    }
}
