package com.pojavfps.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.pojavfps.config.FPSConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.List;

public class FPSMenuScreen extends Screen {

    // Tab selecionada
    private int selectedTab = 0;
    private static final String[] TABS = {"RENDER", "ENTIDADE", "MUNDO", "POJAV"};

    // Scroll
    private int scrollOffset = 0;
    private static final int ITEM_HEIGHT = 22;

    // Layout
    private int menuX, menuY, menuW, menuH;

    // Lista de opções da tab atual
    private final List<ToggleOption> options = new ArrayList<>();

    // Botão aplicar
    private Button applyButton;

    // Animação de abertura
    private float openAnim = 0f;

    public FPSMenuScreen() {
        super(Component.literal("PojavFPS"));
    }

    @Override
    protected void init() {
        menuW = 320;
        menuH = 260;
        menuX = (width - menuW) / 2;
        menuY = (height - menuH) / 2;

        buildTabOptions();

        applyButton = Button.builder(
            Component.literal("✔ APLICAR"),
            btn -> {
                FPSConfig.applyAll();
                this.onClose();
            })
            .bounds(menuX + menuW - 110, menuY + menuH - 30, 100, 20)
            .build();
        addRenderableWidget(applyButton);
    }

    private void buildTabOptions() {
        options.clear();
        scrollOffset = 0;
        clearWidgets();

        switch (selectedTab) {
            case 0 -> { // RENDER
                options.add(new ToggleOption("Gráficos Rápidos (Fast)",
                    "Muda modo gráfico para FAST. +15 FPS",
                    () -> FPSConfig.fastGraphics, v -> FPSConfig.fastGraphics = v));
                options.add(new ToggleOption("Desligar Nuvens",
                    "Remove nuvens da cena. +8 FPS",
                    () -> FPSConfig.disableClouds, v -> FPSConfig.disableClouds = v));
                options.add(new ToggleOption("Desligar Névoa",
                    "Remove fog de distância. +6 FPS",
                    () -> FPSConfig.disableFog, v -> FPSConfig.disableFog = v));
                options.add(new ToggleOption("Partículas Reduzidas",
                    "Mínimo de partículas. +10 FPS",
                    () -> FPSConfig.reducedParticles, v -> FPSConfig.reducedParticles = v));
                options.add(new ToggleOption("Desligar Chuva/Neve",
                    "Sem renderização de clima. +12 FPS",
                    () -> FPSConfig.disableWeather, v -> FPSConfig.disableWeather = v));
                options.add(new ToggleOption("Limitar Framerate",
                    "Limita FPS para economizar bateria",
                    () -> FPSConfig.limitFramerate, v -> FPSConfig.limitFramerate = v));
            }
            case 1 -> { // ENTIDADE
                options.add(new ToggleOption("Entity Culling",
                    "Pula render de entidades fora de visão. +20 FPS",
                    () -> FPSConfig.entityCulling, v -> FPSConfig.entityCulling = v));
                options.add(new ToggleOption("Desligar Sombras",
                    "Remove sombras de entidades. +10 FPS",
                    () -> FPSConfig.disableEntityShadows, v -> FPSConfig.disableEntityShadows = v));
                options.add(new ToggleOption("Limitar Tick de Entidades",
                    "Reduz processamento de mobs distantes. +15 FPS",
                    () -> FPSConfig.limitEntityTick, v -> FPSConfig.limitEntityTick = v));
                options.add(new ToggleOption("Pular Entidades Off-screen",
                    "Entidades fora da tela não são processadas",
                    () -> FPSConfig.skipOffscreenEntities, v -> FPSConfig.skipOffscreenEntities = v));
            }
            case 2 -> { // MUNDO
                options.add(new ToggleOption("Folhas Rápidas (Fast Leaves)",
                    "Folhas opacas, sem transparência. +8 FPS",
                    () -> FPSConfig.fastLeaves, v -> FPSConfig.fastLeaves = v));
                options.add(new ToggleOption("Reduzir Atualizações de Chunk",
                    "Menos rebuilds de chunk por tick. +12 FPS",
                    () -> FPSConfig.minimalChunkUpdates, v -> FPSConfig.minimalChunkUpdates = v));
                options.add(new ToggleOption("FOV Reduzido",
                    "FOV menor = menos geometria renderizada",
                    () -> FPSConfig.reducedFOV, v -> FPSConfig.reducedFOV = v));
            }
            case 3 -> { // POJAV
                options.add(new ToggleOption("Modo PojavLauncher",
                    "Otimizações específicas pra Android/Pojav",
                    () -> FPSConfig.pojavMode, v -> FPSConfig.pojavMode = v));
                options.add(new ToggleOption("HUD Reduzido",
                    "Remove elementos desnecessários do HUD",
                    () -> FPSConfig.reducedHUD, v -> FPSConfig.reducedHUD = v));
                options.add(new ToggleOption("Otimização Touch",
                    "Ajusta render para dispositivos touch",
                    () -> FPSConfig.touchOptimize, v -> FPSConfig.touchOptimize = v));
            }
        }

        // Recriar botão aplicar
        applyButton = Button.builder(
            Component.literal("✔ APLICAR"),
            btn -> {
                FPSConfig.applyAll();
                this.onClose();
            })
            .bounds(menuX + menuW - 110, menuY + menuH - 30, 100, 20)
            .build();
        addRenderableWidget(applyButton);

        // Botão TUDO ON
        addRenderableWidget(Button.builder(
            Component.literal("MAX FPS"),
            btn -> {
                FPSConfig.fastGraphics = true;
                FPSConfig.disableClouds = true;
                FPSConfig.disableFog = true;
                FPSConfig.reducedParticles = true;
                FPSConfig.disableWeather = true;
                FPSConfig.entityCulling = true;
                FPSConfig.disableEntityShadows = true;
                FPSConfig.limitEntityTick = true;
                FPSConfig.skipOffscreenEntities = true;
                FPSConfig.fastLeaves = true;
                FPSConfig.minimalChunkUpdates = true;
                FPSConfig.pojavMode = true;
                FPSConfig.renderDistance = 6;
                FPSConfig.simulationDistance = 4;
                FPSConfig.applyAll();
                buildTabOptions();
            })
            .bounds(menuX + 8, menuY + menuH - 30, 80, 20)
            .build()
        );
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        // Animação suave de abertura
        openAnim = Math.min(1f, openAnim + partialTick * 0.2f);
        float scale = 0.85f + 0.15f * openAnim;
        float alpha = openAnim;

        // Fundo escuro
        this.renderBackground(gfx);

        gfx.pose().pushPose();
        gfx.pose().translate(width / 2f, height / 2f, 0);
        gfx.pose().scale(scale, scale, 1f);
        gfx.pose().translate(-width / 2f, -height / 2f, 0);

        int alphaColor = (int)(alpha * 255) << 24;

        // Painel principal — fundo escuro
        gfx.fill(menuX, menuY, menuX + menuW, menuY + menuH, alphaColor | 0x0D1117);

        // Borda verde
        drawBorder(gfx, menuX, menuY, menuW, menuH, alphaColor | 0x00FF88);

        // Header
        gfx.fill(menuX, menuY, menuX + menuW, menuY + 22, alphaColor | 0x001A0A);
        drawBorderBottom(gfx, menuX, menuY + 22, menuW, alphaColor | 0x00FF88);

        // Título
        String title = "⚡ POJAV FPS CLIENT";
        int titleW = font.width(title);
        gfx.drawString(font, title, menuX + (menuW - titleW) / 2, menuY + 7, alphaColor | 0x00FF88, false);

        // Versão
        String ver = "v1.0 · 1.20.1 FORGE";
        gfx.drawString(font, ver, menuX + menuW - font.width(ver) - 6, menuY + 7, alphaColor | 0x336644, false);

        // TABS
        int tabY = menuY + 24;
        int tabW = menuW / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            int tx = menuX + i * tabW;
            boolean active = i == selectedTab;
            int tabBg = active ? (alphaColor | 0x003322) : (alphaColor | 0x060D0A);
            int tabFg = active ? (alphaColor | 0x00FF88) : (alphaColor | 0x336644);
            gfx.fill(tx, tabY, tx + tabW, tabY + 14, tabBg);
            if (active) {
                // linha inferior destaque
                gfx.fill(tx, tabY + 12, tx + tabW, tabY + 14, alphaColor | 0x00FF88);
            }
            int tw = font.width(TABS[i]);
            gfx.drawString(font, TABS[i], tx + (tabW - tw) / 2, tabY + 3, tabFg, false);
        }

        // Área de opções
        int optAreaY = tabY + 16;
        int optAreaH = menuH - 16 - 38 - 16 - 22; // top to bottom minus header/tab/footer
        int optAreaX = menuX + 6;
        int optAreaW = menuW - 12;

        // Clip (scissor) para o scroll
        RenderSystem.enableScissor(
            menuX + 4,
            optAreaY,
            menuX + menuW - 4,
            optAreaY + optAreaH
        );

        for (int i = 0; i < options.size(); i++) {
            int oy = optAreaY + i * ITEM_HEIGHT - scrollOffset;
            if (oy + ITEM_HEIGHT < optAreaY || oy > optAreaY + optAreaH) continue;
            options.get(i).render(gfx, optAreaX, oy, optAreaW, ITEM_HEIGHT - 2, mouseX, mouseY, alpha, font);
        }

        RenderSystem.disableScissor();

        // Linha separadora antes do rodapé
        gfx.fill(menuX + 4, menuY + menuH - 34, menuX + menuW - 4, menuY + menuH - 33, alphaColor | 0x003322);

        gfx.pose().popPose();

        super.render(gfx, mouseX, mouseY, partialTick);

        // FPS atual no canto
        String fpsStr = "FPS: " + minecraft.getFps();
        gfx.drawString(font, fpsStr, menuX + 6, menuY + menuH - 28, 0xFF00FF88, false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // Clique nas tabs
        int tabY = menuY + 24;
        int tabW = menuW / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            int tx = menuX + i * tabW;
            if (mx >= tx && mx < tx + tabW && my >= tabY && my < tabY + 14) {
                selectedTab = i;
                buildTabOptions();
                return true;
            }
        }

        // Clique nos toggles
        int optAreaY = tabY + 16;
        int optAreaX = menuX + 6;
        int optAreaW = menuW - 12;
        for (int i = 0; i < options.size(); i++) {
            int oy = optAreaY + i * ITEM_HEIGHT - scrollOffset;
            if (options.get(i).mouseClicked(mx, my, optAreaX, oy, optAreaW, ITEM_HEIGHT - 2)) {
                return true;
            }
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        int maxScroll = Math.max(0, options.size() * ITEM_HEIGHT - 120);
        scrollOffset = (int) Mth.clamp(scrollOffset - delta * 10, 0, maxScroll);
        return true;
    }

    @Override
    public boolean isPauseScreen() {
        return false; // Não pausa o jogo
    }

    // ─── Helpers de desenho ───────────────────────────────────────

    private void drawBorder(GuiGraphics gfx, int x, int y, int w, int h, int color) {
        gfx.fill(x, y, x + w, y + 1, color);         // top
        gfx.fill(x, y + h - 1, x + w, y + h, color); // bottom
        gfx.fill(x, y, x + 1, y + h, color);          // left
        gfx.fill(x + w - 1, y, x + w, y + h, color);  // right
    }

    private void drawBorderBottom(GuiGraphics gfx, int x, int y, int w, int color) {
        gfx.fill(x, y, x + w, y + 1, color);
    }
}
