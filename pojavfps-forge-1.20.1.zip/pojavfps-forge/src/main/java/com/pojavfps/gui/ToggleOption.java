package com.pojavfps.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class ToggleOption {

    private final String label;
    private final String description;
    private final Supplier<Boolean> getter;
    private final Consumer<Boolean> setter;

    public ToggleOption(String label, String description, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        this.label = label;
        this.description = description;
        this.getter = getter;
        this.setter = setter;
    }

    public void render(GuiGraphics gfx, int x, int y, int w, int h, int mouseX, int mouseY, float alpha, Font font) {
        boolean on = getter.get();
        int alphaI = (int)(alpha * 255) << 24;

        // Fundo do item
        boolean hovered = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
        int bg = hovered ? (alphaI | 0x001A0A) : (alphaI | 0x080F09);
        gfx.fill(x, y, x + w, y + h, bg);

        // Borda esquerda colorida (verde se ON, cinza se OFF)
        int accent = on ? (alphaI | 0x00FF88) : (alphaI | 0x334433);
        gfx.fill(x, y, x + 2, y + h, accent);

        // Label
        int labelColor = on ? (alphaI | 0xDDFFEE) : (alphaI | 0x667766);
        gfx.drawString(font, label, x + 7, y + 2, labelColor, false);

        // Descrição menor
        gfx.drawString(font, description, x + 7, y + 11, alphaI | 0x335544, false);

        // Toggle visual (canto direito)
        int toggleX = x + w - 36;
        int toggleY = y + (h - 10) / 2;
        int toggleW = 28;
        int toggleH = 10;

        // Trilho
        int trackColor = on ? (alphaI | 0x006633) : (alphaI | 0x222222);
        gfx.fill(toggleX, toggleY, toggleX + toggleW, toggleY + toggleH, trackColor);

        // Borda do trilho
        gfx.fill(toggleX, toggleY, toggleX + toggleW, toggleY + 1, alphaI | (on ? 0x00FF88 : 0x444444));
        gfx.fill(toggleX, toggleY + toggleH - 1, toggleX + toggleW, toggleY + toggleH, alphaI | (on ? 0x00FF88 : 0x444444));
        gfx.fill(toggleX, toggleY, toggleX + 1, toggleY + toggleH, alphaI | (on ? 0x00FF88 : 0x444444));
        gfx.fill(toggleX + toggleW - 1, toggleY, toggleX + toggleW, toggleY + toggleH, alphaI | (on ? 0x00FF88 : 0x444444));

        // Bolinha
        int knobX = on ? toggleX + toggleW - 11 : toggleX + 1;
        gfx.fill(knobX, toggleY + 1, knobX + 10, toggleY + toggleH - 1, alphaI | (on ? 0x00FF88 : 0x666666));

        // Label ON/OFF
        String onOff = on ? "ON" : "OFF";
        int onOffColor = on ? (alphaI | 0x00FF88) : (alphaI | 0x556655);
        gfx.drawString(font, onOff, toggleX - font.width(onOff) - 4, y + (h - 7) / 2, onOffColor, false);
    }

    public boolean mouseClicked(double mx, double my, int x, int y, int w, int h) {
        if (mx >= x && mx < x + w && my >= y && my < y + h) {
            setter.accept(!getter.get());
            return true;
        }
        return false;
    }
}
