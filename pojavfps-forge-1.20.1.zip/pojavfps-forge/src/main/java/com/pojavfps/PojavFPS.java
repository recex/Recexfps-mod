package com.pojavfps;

import com.mojang.logging.LogUtils;
import com.pojavfps.config.FPSConfig;
import com.pojavfps.keybind.KeyBindings;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod("pojavfps")
public class PojavFPS {

    public static final String MOD_ID = "pojavfps";
    public static final Logger LOGGER = LogUtils.getLogger();

    public PojavFPS() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        modBus.addListener(this::clientSetup);
        MinecraftForge.EVENT_BUS.register(this);
        FPSConfig.init();
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        KeyBindings.register();
        LOGGER.info("[PojavFPS] Mod carregado! Pressione R-Shift para abrir o menu.");
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            KeyBindings.handleKeyPress();
        }
    }
}
